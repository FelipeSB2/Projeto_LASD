/*
 * logic_functions.h
 *
 * Created: 03/12/2020 14:31:25
 *  Author: savio
 */ 

#ifndef LOGIC_FUNCTIONS_H_
#define LOGIC_FUNCTIONS_H_

#include <logic_config.h>
#include <src/logic_config.c>

struct Tela TELA;
struct Edicao edicao;
struct Status_atuadores status;
struct Temp_interrupcao temp_interrupcao;
struct Medicao_ADC medicao_ADC;
struct Config_intervalo_aceitavel config_intervalo_aceitavel;
struct Faixa_de_operacao faixa_de_operacao;
struct Temp_variaveis temp;
struct Historico_da_porta historico_da_porta;
struct Valores_atuais valores_atuais;


#endif /* LOGIC_FUNCTIONS_H_ */