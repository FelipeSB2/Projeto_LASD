#include <atmel_start.h>
#include "logic_functions.h"
#include <util/delay.h>
#include "adc_basic.h"

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	iniciar_sistema();
	
	ADCSRA |= 1<<ADSC;
	
	// Interrup��es globais
	sei();
	
	while (1) {
		_delay_ms(300);
		mudar_tela();
		_delay_ms(300);
	}
}
