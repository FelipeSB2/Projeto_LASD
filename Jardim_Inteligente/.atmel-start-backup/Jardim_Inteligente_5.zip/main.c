#include <atmel_start.h>
#include "logic_functions.h"
#include <util/delay.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	DDRB  |= 0x1F;
	PORTB = 0;
	
	iniciar_sistema();
	while (1) {
		nokia_lcd_write_string("Valor: ", 1);
		nokia_lcd_render();
		_delay_ms(100);
	}
}
