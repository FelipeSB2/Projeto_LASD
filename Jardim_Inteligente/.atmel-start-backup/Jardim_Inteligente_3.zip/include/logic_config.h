/*
 * LOGIC_CONFIG.h
 *
 * Created: 03/12/2020 13:46:06
 *  Author: savio
 */ 


#ifndef LOGIC_CONFIG_H_
#define LOGIC_CONFIG_H_

#include <stdint.h>

// <h> Configura��o do total de p�ginas
// <i> Isso define o total de p�ginas a serem mostradas
#define TOTAL_PAGINAS 4

// </h>

// <h> Configura��o do tamanho do buffer
// <i> Isso define o n�mero de caracteres do buffer
#define tam_vetor 15

// </h>

// <<< end of configuration section >>>

#endif /* LOGIC_CONFIG_H_ */